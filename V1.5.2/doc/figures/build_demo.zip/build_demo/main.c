#include <stdlib.h>
#include <stdio.h>

int func()
{
	printf("hello, world!\r\n");
	return 0;
}
